greeting="Hello, World!"
echo $greeting
for color in red green blue; do
echo "Color: $color"
done

read -p  "Enter a number: " num

if [ $num -gt 0 ]; then
	echo "The number is positive"
elif [ $num -lt 0 ]; then
	echo "The number is negative"
else
	echo "The number is zero"
fi

let num=num+num
echo $num

current_user=`whoami`
echo "Current user: $current_user"
